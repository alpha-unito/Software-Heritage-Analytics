#!/usr/bin/env python3

import argparse
import socket
import json
import os
import subprocess
import time
import uuid
from datetime import datetime
from config import _CONFIG


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')


parser = argparse.ArgumentParser(description="Test Client pycapio")
parser.add_argument("-a", type=str, help="Server IP address")
parser.add_argument("-p", type=int, help="Server Port")
parser.add_argument("-r", type=str, help="Recipe json file")
parser.add_argument("-n", type=str, help="Set App name")
parser.add_argument("-d", type=str2bool, nargs='?', const=True,
                    default=False, help="Activate spark dry run mode.")
parser.add_argument("-m", type=str, default="127.0.0.1",
                    help="Set spark master address")
parser.add_argument("-e", type=str, default="20G", help="Set spark memory")
parser.add_argument("-D", type=str2bool, nargs='?', const=True,
                    default=False, help="Activate spark deploy-mode client (debug mode).")
parser.add_argument("-dir", type=str, help="Dir to save json app output")
parser.add_argument("-sb", type=str, help="Scancode exec path")
parser.add_argument("-si", type=str, help="Scandode index")
parser.add_argument("-rp", type=str, help="Ramdisk path")
parser.add_argument("-gp", type=str, help="Graph path")
parser.add_argument("-op", type=str, help="Output path")

args = parser.parse_args()


profile_time_start = datetime.now()

host = args.a
port = args.p
recipe_file = args.r
app_name = args.n
spark_master_addr = args.m
stream_addr = args.a
dry_run = args.d
spark_mem = args.e
output_dir = args.dir
scancode_exe_path = args.sb
scancode_index_file = args.si
ramdisk_path = args.rp
graph_path = args.gp
output_path = args.op

if args.D is False:
    spark_deploy_mode = "cluster"
else:
    spark_deploy_mode = "client"

spark_submit_path = os.getenv('SPARK_HOME')
orchestator_path = os.getenv('ORCHESTRATOR_HOME')
spark_app_path = os.getenv('SPARK_APP_PATH')

if not spark_app_path:
    print("Export SPARK_APP_PATH")
    quit()

print("dry_run:" + str(dry_run))

start_time = time.perf_counter()
print("Receipe file:" + recipe_file)
recipe_json = json.load(open(recipe_file))
if "app_name" not in recipe_json.keys():
    recipe_json["app_name"] = recipe_file.split("/")[-1]
    print("App name not present set to " + recipe_json["app_name"])


# run_app_path = '~/Software-Heritage-Analytics/Orchestrator/app/'

if app_name is not None:
    print("Change App name: " + recipe_json["app_name"] + " --> " + app_name)
    recipe_json["app_name"] = app_name

streams_num = recipe_json["rules"]["num_slave"]

spark_app_name = recipe_json["app"]

# if "app_path" not in recipe_json.keys():
#     spark_app_path = run_app_path
# else:
#     spark_app_path = recipe_json["app_path"]

# print("App path:"+spark_app_path)
dstream_time = recipe_json["rules"]["dstream_time"]
BUFFER_SIZE = 10000

print("Send recipe to Orchestrator...")
recipe = json.dumps(recipe_json)
# print(recipe)
tcpClientA = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
tcpClientA.connect((host, port))

# MESSAGE = input("Test Client: Enter message / Enter exit:")
tcpClientA.sendall(bytes(recipe, encoding="utf-8"))


addr_local_master = ' local[' + str({streams_num*2}) + '] '
addr_master = "spark://" + str(spark_master_addr) + ":7077 "
data = tcpClientA.recv(BUFFER_SIZE)
print("Received data from Orchestrator:")
if data.decode() != "Abort":
    spark_port = data.decode()
    print("Port:" + spark_port)

    instance = streams_num
    spark_conf = f'--conf "spark.executor.extraJavaOptions=-Dlog4j.configuration=file://{orchestator_path}/src/conf/custom-log4j.properties" \
                 --conf "spark.driver.extraJavaOptions=-Dlog4j.configuration=file://{orchestator_path}/src/conf/custom-log4j.properties" \
                 --conf "spark.executor.instances={instance}" \
                 --conf "spark.executor.memory=110g" \
                 --conf "spark.executor.cores=36" \
                 --conf "spark.default.parallelism={instance * 36}" \
                 --conf "spark.app.id={app_name}_{uuid.uuid4()}"'

    param_spark = f'{spark_conf} \
                    --class "{recipe_json["app_name"]}" \
                    --master {addr_master} \
                    --name {recipe_json["app_name"]} \
                    --deploy-mode {spark_deploy_mode}'
                    
    params_app = str(streams_num) + " " + stream_addr + "\
                " + spark_port + " " + str(dstream_time)
                
    cmd = spark_submit_path + '/bin/spark-submit ' + param_spark + ' \
        ' + spark_app_path + spark_app_name + ' \
        ' + params_app + ' ' + output_dir + ' \
        ' + scancode_exe_path + ' ' + scancode_index_file + ' \
        ' + ramdisk_path + ' ' + graph_path + ' \
        ' + output_path + ' '
            
    print(cmd)
    if not dry_run:
        print("Launch spark APP")
        subprocess.run(cmd, shell=True)
    else:
        print("Spark dry run")


data = tcpClientA.recv(BUFFER_SIZE)
print("Client received data:", data.decode())
execution_time = time.perf_counter() - start_time
print(f"APP execution time: {execution_time:0.4f} seconds ")
profile = open('profile.txt', 'a')
profile.write(
    f'[{profile_time_start}] {args} ({execution_time:0.4f} seconds)\n')
profile.close()

tcpClientA.close()
