import json
import sys


def remove_duplicate_keys_from_file(file_path):
    # Apri il file e leggi il contenuto JSON
    with open(file_path, 'r') as file:
        json_content = file.read()

    # Carica il JSON
    data = json.loads(json_content)

    # Trasforma il JSON in un dizionario
    data_dict = dict(data)

    # Rimuovi le chiavi duplicate
    unique_keys = list(set(data_dict.keys()))

    # Crea un nuovo dizionario senza chiavi duplicate
    new_data_dict = {key: data_dict[key] for key in unique_keys}

    # Converti il dizionario in JSON
    new_json_content = json.dumps(new_data_dict, indent=2)

    # Sovrascrivi il file con il nuovo JSON
    with open(file_path, 'w') as file:
        file.write(new_json_content)


file_path = sys.argv[1]
remove_duplicate_keys_from_file(file_path)
