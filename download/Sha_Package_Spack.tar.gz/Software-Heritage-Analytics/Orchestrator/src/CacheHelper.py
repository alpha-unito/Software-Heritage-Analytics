import struct
import mimetypes
import io
import socket
import time
# from utils import *

# These variables are constants used in the CacheHelper class to define the sizes and values of
# different fields in the protocol used for communication with the cache server.
OP_SIZE = 1
DATA_SIZE = 8
KEY_SIZE = 40
OP_GET = 0
OP_PUT = 1
OP_OK = 20
OP_FAILED = 21


# The `CacheHelper` class is a Python class that provides methods for interacting with a chachemire.
# The CacheHelper class is a helper class for caching data.
class CacheHelper():
    def __init__(self, host="127.0.0.1", port=13000, debug=False):
        '''The function initializes a socket connection with a specified host and port, and sets the debug
        mode.
        
        Parameters
        ----------
        host, optional
            The `host` parameter is the IP address or hostname of the server you want to connect to. By
        default, it is set to "127.0.0.1", which is the loopback address and refers to the local machine.
        You can change it to the IP address or hostname of
        port, optional
            The `port` parameter is used to specify the port number on which the socket will listen for
        incoming connections. In this case, the default value is set to `13000`.
        debug, optional
            The `debug` parameter is a boolean flag that determines whether or not to enable debug mode. When
        debug mode is enabled, additional information and logs may be printed or displayed to help with
        debugging and troubleshooting.
        
        '''

        self.socket = None
        self.cache_error = False
        self.debug = debug
        self.__handle_CONNECT(host, port)

    def custom_print(self, *args, **kwargs):
        '''The `custom_print` function is a wrapper around the built-in `print` function that only prints the
        arguments if the `debug` attribute of the object is `True`.
        
        Returns
        -------
            The `print(*args, **kwargs)` function is being called, but the return value of the `print` function
        is not being captured or returned. Therefore, the `custom_print` function will not have a return
        value.
        
        '''
        if self.debug:
            return print(*args, **kwargs)

    def __handle_CONNECT(self, ip, port):
        """
        The function establishes a TCP connection to a specified IP address and port.

        :param ip: The `ip` parameter is the IP address of the server that the socket will connect to. It is
        a string representing the IP address in the format "xxx.xxx.xxx.xxx"
        :param port: The `port` parameter is the port number that the socket will connect to. It specifies
        the port on the remote server that the socket will establish a connection with
        :return: a boolean value. If the connection is successfully established, it returns True. If there
        is an IOError, it prints the error message and returns False.
        """
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((ip, port))

            # self.custom_print("cache connected")
            return True
        except IOError as e:
            self.custom_print(str(e))
            return False

    def __handle_RECEIVE(self):
        """
        The function handles the receiving of data packets and returns the received data if successful.
        :return: a tuple. The first element of the tuple is a boolean value indicating whether the
        operation was successful or not. The second element of the tuple is the received data, which is
        either a byte string or None depending on the success of the operation.
        """
        try:
            RPL_HDR_SIZE = OP_SIZE+DATA_SIZE
            header_data = self.__recv_n_bytes(RPL_HDR_SIZE)
            # logging.debug("receive GET " + str(header_data))
            if len(header_data) == RPL_HDR_SIZE:
                op, data = struct.unpack(f'b{DATA_SIZE}s', header_data)
                # logging.debug("receive GET op:" + str(op))

                if op == OP_OK:
                    msg_len = int.from_bytes(data, byteorder='big')
                    # logging.debug("receive GET data size:" + str(msg_len))
                    data = self.__recv_n_bytes(msg_len)
                    if len(data) == msg_len:

                        return True, data
                    else:
                        # self.logging.debug('file receive lenght error')
                        return False
                if op == OP_FAILED:

                    msg_len = int.from_bytes(data, byteorder='big')
                    # logging.debug("receive GET data size:" + str(msg_len))
                    data = self.__recv_n_bytes(msg_len)
                    if len(data) == msg_len:
                        self.cache_error = data.decode()
                        # self.logging.debug("receive GET error:" + data.decode())
                    else:
                        return False, None
                        # self.logging.debug('file receive lenght error')
                    return False, None

            # self.logging.debug('Socket closed prematurely')
        except IOError as e:
            # self.logging.debug("IOError " + str(e))
            return False, None

    def prepare_string(self, data):
        """
        The function `prepare_string` takes a string as input and returns a BytesIO object containing the
        encoded version of the string.

        :param data: The `data` parameter is a string that represents the data that needs to be prepared
        :return: an instance of the `io.BytesIO` class, which is created by encoding the `data` string into
        bytes using the `encode()` method.
        """
        return io.BytesIO(data.encode())

    def prepare_file(self, file_path):
        """
        The function prepares a file by reading its content as bytes and returning it as a BytesIO
        object.

        :param file_path: The file path is the location of the file that you want to prepare. It should
        be a string that specifies the path to the file on your computer. For example,
        "C:/Users/username/Documents/file.txt" or "/home/username/Documents/file.txt"
        :return: a `BytesIO` object.
        """
        byte_content = b""
        try:
            with open(file_path, 'rb') as file:
                byte_content = file.read()
        except:
            pass
        bytesio_object = io.BytesIO(byte_content)
        return bytesio_object

    def __recv_n_bytes(self, n):
        """
        The function receives a specified number of bytes from a socket connection.

        :param n: The parameter `n` represents the number of bytes that the function is expected to
        receive
        :return: the data received from the socket, which is stored in the variable "data".
        """
        data = b''
        while len(data) < n:
            chunk = self.socket.recv(n - len(data))
            if chunk == b'':
                break
            data += chunk
        return data

    def put(self, file_name, file_bytes):
        """
        The function sends a file to cachemire and returns True if the operation is successful,
        False otherwise.

        :param file_name: The name of the file that you want to put in the cache. It should be a string
        representing the file name
        :param file_bytes: The `file_bytes` parameter is expected to be a `BytesIO` object that contains
        the bytes of the file that you want to send to the cache
        :return: a boolean value. It returns True if the operation is successful (OP_OK), and False
        otherwise.
        """
        name = file_name.encode()
        op = (OP_PUT).to_bytes(OP_SIZE, byteorder='big')
        file_byte = file_bytes.getvalue()
        size = (len(file_byte)).to_bytes(DATA_SIZE, byteorder='big')
        msg = struct.pack(f'c{KEY_SIZE}s{DATA_SIZE}s', op, name, size)
        # send PUT header to cache
        try:
            self.socket.sendall(msg)
        except IOError as e:
            return False

        # send PUT data to cache
        try:
            self.socket.sendall(file_byte)
        except IOError as e:
            return False

        # receive
        RPL_HDR_SIZE = OP_SIZE+DATA_SIZE
        header_data = self.__recv_n_bytes(RPL_HDR_SIZE)
        if len(header_data) == RPL_HDR_SIZE:
            op, data = struct.unpack(f'b{DATA_SIZE}s', header_data)
            if op == OP_FAILED:
                msg_len = int.from_bytes(data, byteorder='big')
                data = self.__recv_n_bytes(msg_len)

                if len(data) == msg_len:
                    return False
                else:
                    return False
            if op == OP_OK:
                self.custom_print(f"Cache PUT {file_name}")
                self.socket.close()
                return True
        return False

    def get(self, file_name, iterations=5):
        '''The `get` function sends a GET request to cachemire to retrieve a file, and returns the status
        of the request and the file data as a BytesIO object.

        Parameters
        ----------
        file_name
            The name of the file that you want to retrieve from the cache.
        iterations, optional
            The `iterations` parameter is an integer that represents the number of times the `get` function
        will attempt to retrieve a file from the cache. It is used to control the number of retries in case
        of failures or errors during the retrieval process.

        Returns
        -------
            a tuple containing a boolean value and a BytesIO object. The boolean value represents the status of
        the operation (True for success, False for failure), and the BytesIO object represents the file data
        retrieved from the cache.

        '''
        if iterations == 0:
            return False, b""
        iterations -= 1
        inmemory_file = b""
        name = file_name.encode()
        op = (OP_GET).to_bytes(OP_SIZE, byteorder='big')
        msg = struct.pack(f'c{KEY_SIZE}s', op, name)
        # self.custom_print("SEND GET:" + str(msg))

        # send GET to cache
        try:
            self.socket.sendall(msg)
        except IOError as e:
            self.custom_print(e)
            return False, inmemory_file

        # verify GET return
        try:
            status, file_byte = self.__handle_RECEIVE()
        except Exception as e:
            print(e) 
            status, file_byte = self.get(file_name, iterations) 
            
        if status is False:
            self.custom_print("Cache MISS " + file_name)
            self.socket.close()

            return False, inmemory_file

        else:
            
            self.custom_print("Cache HIT " + file_name)
            self.socket.close()

            # # schedule stream file
            inmemory_file = io.BytesIO(file_byte)
            # self.custom_print(inmemory_file)

        return True, inmemory_file