import json
import csv
import sys
import glob
import requests


def extractJsonFromResults(results_match):
    output = []

    files = glob.glob(
        f"/beegfs/home/gspinate/Software-Heritage-Analytics/Orchestrator/spark_output/{results_match}*/*.json")

    for f in files:
        with open(f, 'r') as result_file:
            lines = result_file.readlines()
            for line in lines:
                json_line = json.loads(line)
                output.append(json_line)
    return output


def extractDictFromCsv(csv_file):
    with open(csv_file, 'r') as csv_file:
        csvreader = csv.reader(csv_file)

        data = {}
        for row in csvreader:
            if len(row) >= 3:
                key = row[2]
                data[key] = {
                    "url": row[1],
                    "name": row[0]
                }
    return data


def apiRequest(api_url, path, token):
    headers = {"Authorization": f"token {token}"}
    url = f"{api_url}/{path}"
    response = requests.get(url=url, headers=headers).json()
    return response


def getLanguageAndTopics(api_url, token):
    languages = apiRequest(api_url, 'languages', token)
    topics = apiRequest(api_url, 'topics', token)
    topics = topics['names']
    keys = list(languages.keys())
    language = keys[0] if len(keys) > 0 else []

    return language, topics


def extractGitApiUrlAndName(project_id, csv_dict):
    project = csv_dict[project_id]
    url = project["url"]
    name = project["name"]
    api_url = url.replace("github.com", "api.github.com/repos")
    return api_url, name


def extendResultsWithInformations(results_array, csv_dict):
    extended_results = []
    for result in results_array:
        project_id = result['project_id']
        url, name = extractGitApiUrlAndName(project_id, csv_dict)
        language, topics = getLanguageAndTopics(
            url, "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")
        result["project_name"] = name
        result["project_main_language"] = language
        result["project_keywords"] = topics
        extended_results.append(result)
    return extended_results


def writeCompleteResultToFile(extended_results, out_file):
    with open(out_file, 'w+') as outfile:
        for result in extended_results:
            outfile.write(f"{json.dumps(result)}\n")
    print(f"All results are written in {out_file}")


# if __name__ == "__main__":

#     results_match = sys.argv[1]
#     csv_file = sys.argv[2]
#     output_file = sys.argv[3]

#     results_array = extractJsonFromResults(results_match)

#     csv_dict = extractDictFromCsv(csv_file)

#     extended_results = extendResultsWithInformations(results_array, csv_dict)

#     print(extended_results)
    # writeCompleteResultToFile(extended_results, f"./{output_file}")


if __name__ == "__main__":
    csv_file = "/beegfs/home/gspinate/Software-Heritage-Analytics/Orchestrator/Top100Projects/csv_urls/PHP.csv"
    with open(csv_file, 'r') as csv_file:
        csvreader = csv.reader(csv_file)

        data = {}
        for row in csvreader:
            if len(row) >= 3:
                key = row[2]
                data[key] = {
                    "url": row[1],
                    "name": row[0]
                }

                url = data[key]["url"]
                api_url = url.replace("github.com", "api.github.com/repos")
                token = "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"

                headers = {"Authorization": f"token {token}"}
                url = f"{api_url}"
                response = requests.get(url=url, headers=headers).json()
                data[key]['size'] = response['size']
                print(data)

    with open("test.json", 'w+') as outfile:
        outfile.write(json.dumps(data))
