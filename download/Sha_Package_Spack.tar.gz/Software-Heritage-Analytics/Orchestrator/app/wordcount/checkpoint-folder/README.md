
# README
This folder is used to store Spark checkpoint data