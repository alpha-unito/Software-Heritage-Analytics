<td {{ $attributes->merge(['class' => 'hidden px-3 py-3.5 text-sm text-gray-500 lg:table-cell border-t border-gray-200']) }}>
    {{ $slot }}
</td>
