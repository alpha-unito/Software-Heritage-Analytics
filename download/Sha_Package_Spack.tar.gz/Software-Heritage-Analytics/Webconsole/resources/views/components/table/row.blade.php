<tr {{ $attributes->merge([]) }}>
    {{ $slot }}
</tr>
